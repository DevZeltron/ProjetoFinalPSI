#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <locale.h>
#include <string.h>
#include <conio.h>
#include <conio.c>


struct pop
{
    char nome[50];
    char senha[50];
    char file[100];
} login;  //declarao struct com nome pop e é usada para a parte do login

struct rock
{
    char name[50];
    char passw[50];
} cadastro;  //declarao struct com nome rock e é usada para a parte do cadastro

struct rap
{
    int cd, sc[5];
    float dindin;
} pag;

struct koncarne
{
    char nome[50];
    float preco;
    int quantidade;

} produtosSel[10];

int main()
{
    setlocale(LC_ALL,"Portuguese");
    start:;
    system("cls");
    int opcao;
    int found;

textcolor(YELLOW);
    printf(R"EOF(
________       ______             ______       _____________                         _____
__  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
_____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
/____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
       /_/                                                                                               )EOF");


    printf("\nBem-vindo a Splash Pizzaria, a melhor pizza do bairro!!");
    wprintf(L"\nAntes de começar, ja possui conta na nossa plataforma?"
            "\n\n1 - Sim"
            "\n2 - Não"
            "\n\n>");
    scanf("%i",&opcao);

    if(opcao==1)
    {

textcolor(YELLOW);
        printf("\nNome:");
        scanf("%s",&login.nome);

        printf("\nSenha:");
        scanf("%s",&login.senha);

     strcpy(login.file,login.nome);
     strcat(login.file,login.senha);

      FILE*aq=fopen(login.file,"r");

        if (aq != NULL){
        textcolor(GREEN);
        printf("\nLogin feito com sucesso!\n");
        printf("\nCarregando, estamos a lhe direcionar para o site!\n");

        for(int s=0; s<3; s++)
        {

            printf(".");
            sleep(1);
        }
        textcolor(RED);
        printf("\n\nERROR: 404 Bad Gateway!\n");
        textcolor(GREEN);
        wprintf(L"\nBrincadeira o site ja está carregando :)\n");
        for(int s=0; s<3; s++)
        {

            printf(".");
            sleep(2);
        }

        system("cls");
        produtos();

    }
    else
    {
        textcolor(RED);
        printf("\nLogin errado, tente novamente!");
        Sleep(1000);
        textcolor(WHITE);
        goto start;
    }

    } //fecha o if(opcao==1)

    else  //parte da criação da conta
    {

        sign();
        goto start;
    }

    return 0;

}



void produtos()
{

    int opt, pzc=0, pzfc=0, pzqq=0, pzb=0, pzan=0, bebsi=0, z, n, numProdutos=0;
    float sum=0, sumt=0, sumpagar=0;
    do
    {
        textcolor(LIGHTBLUE);
        printf("\n---BEM-VINDO(A) NOVAMENTE %s :)---",strupr(login.nome));
        //printf("\n\n");
        printf(R"EOF(
        _....._
    _.:`.--|--.`:._
  .: .'\o  | o /'. '.
 // '.  \ o|  /  o '.\
//'._o'. \ |o/ o_.-'o\\
|| o '-.'.\|/.-' o   ||
||--o--o-->|             )EOF");

        printf("\n\n");
        wprintf(L"\nSelecione qual pizza deseja saborear hoje:"
                L"\n(1) -> Pizza de Calabresa -> 15 Euros"
                L"\n(2) -> Pizza de Frango e Catupiry -> 19.50 Euros"
                L"\n(3) -> Pizza Quatro Queijos -> 19.50 Euros"
                L"\n(4) -> Pizza de Barbecue -> 15 Euros"
                L"\n(5) -> Pizza Ananás -> 30 Euros"
                L"\n(6) -> Pepsi Max Zero -> 2 Euros"
                L"\n(7) -> Ir para a Área de pagamento"
                "\n>");
        scanf("%i",&opt);

        switch(opt)
        {
            textcolor(WHITE);
        case 1:
            pzc=15;
            wprintf(L"\nQuantas pizzas de calabresa deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzc=pzc*z;
            strcpy(produtosSel[numProdutos].nome, "Pizza de Calabresa");
                produtosSel[numProdutos].preco = 15.0;
                produtosSel[numProdutos].quantidade = z;
                numProdutos++;
            break;
        case 2:
            pzfc=19.50;
            wprintf(L"\nQuantas pizzas de frango e catupiry deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzfc=pzfc*z;
            strcpy(produtosSel[numProdutos].nome, "Pizza de Frango e Catupiry");
                produtosSel[numProdutos].preco = 19.50;
                produtosSel[numProdutos].quantidade = z;
                numProdutos++;
            break;
        case 3:
            pzqq=19.50;
            wprintf(L"\nQuantas pizzas de Quatro queijos deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzqq=pzqq*z;
            strcpy(produtosSel[numProdutos].nome, "Pizza Quatro Queijos");
                produtosSel[numProdutos].preco = 19.50;
                produtosSel[numProdutos].quantidade = z;
                numProdutos++;
            break;
        case 4:
            pzb=15;
            wprintf(L"\nQuantas pizzas de Barbecue deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzb=pzb*z;
            strcpy(produtosSel[numProdutos].nome, "Pizza de Barbecue");
                produtosSel[numProdutos].preco = 15.0;
                produtosSel[numProdutos].quantidade = z;
                numProdutos++;
            break;
        case 5:
            pzan=30;
            wprintf(L"\nQuantas pizzas de Ananás deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzan=pzan*z;
            strcpy(produtosSel[numProdutos].nome, "Pizza Ananás");
                produtosSel[numProdutos].preco = 30.0;
                produtosSel[numProdutos].quantidade = z;
                numProdutos++;
            break;
        case 6:
            bebsi=2;
            wprintf(L"\nQuantas bebsis precisa?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            bebsi=bebsi*z;
            strcpy(produtosSel[numProdutos].nome, "Pepsi Max Zero");
                produtosSel[numProdutos].preco = 2.0;
                produtosSel[numProdutos].quantidade = z;
                numProdutos++;
            break;

        default: printf("\n");
            break;
        }
textcolor(LIGHTMAGENTA);
        wprintf(L"\nÉ tudo o que precisa?"
                "\nSe deseja adicionar mais coisas, aperte 1"
                L"\nPara ir até a Área de Pagamento, aperte 7"
                "\n>");
        scanf("%i",&n);
        system("cls");

    }while(n!=7);

    sumpagar=pzc+pzfc+pzqq+pzb+pzan+bebsi; //"total a pagar"
    sum=pzc+pzfc+pzqq+pzb+pzan+bebsi;
    sumt=pzc+pzfc+pzqq+pzb+pzan+bebsi; //troco
start:;

//parte que o utilizador paga

    textcolor(RED);
    wprintf(L"\nValor total a pagar é de: %0.2f\n",sum);
    textcolor(GREEN);
    wprintf("\nComo deseja pagar?"
           L"\n(1) -> Com Cartão de Crédtio"
           "\n(2) -> Dinheiro"
           "\n>");
           scanf("%i",&pag.cd);

textcolor(WHITE);

           switch(pag.cd)
           {

       case 1:
        wprintf(L"\nDigite a senha do seu cartão"
                   "\n>");
            scanf("%i",&pag.sc);

            printf("\nRealizando a compra");
            for(int x=0;x<3;x++){
                printf(".");
                sleep(1);
              }

              printf("\nAguarde um momento por favor!");
              for(int y=0;y<3;y++){
                printf(".");
                sleep(2);
                }
                textcolor(GREEN);
              printf("\n\nCompra realizada com sucesso!");
              textcolor(GREEN);
              printf("\n\nPor favor, aguarde o Delivery de 10 segundos!");
                     sleep(1);
                     textcolor(GREEN);
                     system("cls");

                     printf(R"EOF(

            ________       ______             ______       _____________                         _____
            __  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
            _____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
            ____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
            /____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
                    /_/                                                                                               )EOF");



       printf("\n\n\t\t\tA sua pizza chegou!"
              "\n\t\t\tEspero que goste da nossa pizza, %s :)",strlwr(login.nome));
       wprintf(L"\n\n\t\t\tPor favor, verifique o seu talão\n");

              FILE*recibo;

              recibo=fopen("recibo.txt","w");

              fprintf(recibo,"SPLASH PIZZARIA"
                      "\n\nMorada: 1000 Av. Pedro Teixeira, Lisboa, Portugal"
                      "\nNIF: 295230014");
                      for(int i = 0; i<numProdutos;i++){
                        fprintf(recibo,"\nProduto(s) selecionado(s): %s"
                                "\nQuantidade: %i"
                                "\nPreço: %0.2f",produtosSel[i].nome,produtosSel[i].quantidade, produtosSel[i].preco);
                      }

                        fprintf(recibo,"\nMétodo de pagamento: Cartão de Crédito");
               fprintf(recibo,"\nTotal a pagar: %0.2f"
                "\n\nObrigado pela sua preferência!",sumpagar);

                fclose(recibo);
        break;

       case 2:
           printf("\nCom que quantia pretende pagar?"
                  "\n>");
           scanf("%f",&pag.dindin);

            if(pag.dindin>sum)
            {
                printf("\nRealizando a compra");
            for(int x=0;x<3;x++)
            {
                printf(".");
                sleep(1);
            }

              printf("\nAguarde um momento por favor!");
              for(int y=0;y<3;y++){
                printf(".");
                sleep(2);
                }
                textcolor(GREEN);
              printf("\n\nCompra realizada com sucesso!");
              textcolor(GREEN);
              printf("\n\nPor favor, aguarde o Delivery de 10 segundos!");
                     sleep(1);
                     textcolor(GREEN);
                     system("cls");

                     printf(R"EOF(

            ________       ______             ______       _____________                         _____
            __  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
            _____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
            ____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
            /____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
                    /_/                                                                                               )EOF");



       printf("\n\n\t\t\tA sua pizza chegou!"
              "\n\t\t\tEspero que goste da nossa pizza, %s :)",strlwr(login.nome));
       wprintf(L"\n\n\t\t\tPor favor, verifique o seu talão\n");

              FILE*recibodinheiro;

              recibodinheiro=fopen("recibodinheiro.txt","w");

              fprintf(recibodinheiro,"SPLASH PIZZARIA"
                      "\n\nMorada: 1000 Av. Pedro Teixeira, Lisboa, Portugal"
                      "\nNIF: 295230014");
                      for(int i = 0; i<numProdutos;i++){
                        fprintf(recibodinheiro,"\nProduto(s) selecionado(s): %s"
                                "\nQuantidade: %i"
                                "\nPreço: %0.2f",produtosSel[i].nome,produtosSel[i].quantidade, produtosSel[i].preco);
                      }
                      sumt=sum-pag.dindin;
                     fprintf(recibodinheiro,"\nMétodo de pagamento: Dinheiro");
               fprintf(recibodinheiro,"\nTotal a pagar: %0.2f"
                       "\nTroco: %.2f"
                "\n\nObrigado pela sua preferência!",sum,sumt);

                fclose(recibo);
       break;

        default: wprintf(L"\nOpcão Errada!");
        Sleep(1500);
        system("cls");
        goto start;
            }
            else
            {
                sumpagar=sum-pag.dindin;
                wprintf(L"\nVocê falta pagar %0.2f Euros",sumpagar);
                Sleep(1500);
                system("cls");
                goto start;
            }



           }


           /*if(pag.cd==1)
            {
            wprintf(L"\nDigite a senha do seu cartão"
                   "\n>");
            scanf("%i",&pag.sc);

            printf("\nRealizando a compra");
            for(int x=0;x<3;x++){
                printf(".");
                sleep(1);
              }

              printf("\nAguarde um momento por favor!");
              for(int y=0;y<3;y++){
                printf(".");
                sleep(2);
                }
                textcolor(GREEN);
              printf("\n\nCompra realizada com sucesso!");
              textcolor(GREEN);
              printf("\n\nPor favor, aguarde o Delivery de 10 segundos!");
                     sleep(1);
                     textcolor(GREEN);
                     system("cls");

                     printf(R"EOF(

            ________       ______             ______       _____________                         _____
            __  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
            _____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
            ____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
            /____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
                    /_/                                                                                               )EOF");



       printf("\n\n\t\t\tA sua pizza chegou!"
              "\n\t\t\tEspero que goste da nossa pizza, %s :)",strlwr(login.nome));
       wprintf(L"\n\n\t\t\tPor favor, verifique o seu talão\n");

              FILE*recibo;

              recibo=fopen("recibo.txt","w");

              fprintf(recibo,"SPLASH PIZZARIA"
                      "\n\nMorada: 1000 Av. Pedro Teixeira, Lisboa, Portugal"
                      "\nNIF: 295230014");
                      for(int i = 0; i<numProdutos;i++){
                        fprintf(recibo,"\nProduto(s) selecionado(s): %s"
                                "\nQuantidade: %i"
                                "\nPreço: %0.2f",produtosSel[i].nome,produtosSel[i].quantidade, produtosSel[i].preco);
                      }
                      if(pag.cd==1){
                        fprintf(recibo,"\nMétodo de pagamento: Cartão de Crédito");
                      }
                      else
                      {
                          printf("\nMétodo de pagamento: Dinheiro");
                      }
               fprintf(recibo,"\nTotal a pagar: %0.2f"
                "\n\nObrigado pela sua preferência!",sum, pag.cd);

                fclose(recibo);
           }*/

}


void sign()
{

    FILE*aq;
    textcolor(LIGHTMAGENTA);

    printf("\nNome:");
    scanf("%s",&login.nome);

    printf("\nSenha:");
    scanf("%s",&login.senha);


    strcat(login.nome,login.senha);

    aq=fopen(login.nome,"w");
    if(aq)
    {
        textcolor(WHITE);
        printf("\nCadastro feito com sucesso!\n");
        Sleep(1500);
    }

}


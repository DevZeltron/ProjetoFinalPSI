#include <stdio.h>
#include <stdlib.h>
#include <conio.c>
#include <windows.h>
#include <locale.h>
#include <string.h>


struct pop
{
    char nome[50], nomearq[50];
    char senha[50], senhaarq[50];
} login;

struct rock
{
    char name[50], namef[50];
    char passw[50], passwf[50];
} cadastro;

int main()
{
    setlocale(LC_ALL,"Portuguese");

    int opcao;
    int found;



    printf(R"EOF(
________       ______             ______       _____________                         _____
__  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
_____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
/____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
       /_/                                                                                               )EOF");


    printf("\nBem-vindo a Splash Pizzaria, a melhor pizza do bairro!!");
    wprintf(L"\nAntes de começar, ja possui conta na nossa plataforma?"
            "\n\n1 - Sim"
            "\n2 - Não"
            "\n\n>");
    scanf("%i",&opcao);

    if(opcao==1)
    {
        FILE*aq=fopen(login.nome,"r");

        printf("\nLogin feito com sucesso!\n");
                printf("\nCarregando, estamos a lhe direcionar para o site!\n");

                for(int s=0; s<3; s++)
                {

                    printf(".");
                    sleep(1);
                }
                wprintf(L"\n\nERROR: 404 Bad Gateway!\n"
                       L"\nBrincadeira o site ja está carregando :)\n");
                for(int s=0; s<3; s++)
                {

                    printf(".");
                    sleep(2);
                }

                system("cls");
                produtos();

}
    else
    {

        sign();
    }

    return 0;
}



void produtos()
{

    int opt, pzc=0, pzfc=0, pzqq=0, pzb=0, pzan=0, bebsi=0, somat, ch;

    do
    {

        printf("\n---BEM-VINDA NOVAMENTE Carla :)---");
        //printf("\n\n");
        printf(R"EOF(
        _....._
    _.:`.--|--.`:._
  .: .'\o  | o /'. '.
 // '.  \ o|  /  o '.\
//'._o'. \ |o/ o_.-'o\\
|| o '-.'.\|/.-' o   ||
||--o--o-->|             )EOF");

        printf("\n\n");
        wprintf(L"\nSelecione qual pizza deseja saborear hoje:"
               L"\n(1) -> Pizza de Calabresa"
               L"\n(2) -> Pizza de Frango e Catupiry"
               L"\n(3) -> Pizza Quatro Queijos"
               L"\n(4) -> Pizza de Barbecue"
               L"\n(5) -> Pizza Ananás"
               L"\n(6) -> Pepsi Max Zero"
               L"\n(7) -> para sair do programa"
               "\n>");
        scanf("%i",&opt);

        switch(opt)
        {
        case 1:
            pzc=0;
            wprintf(L"\nQuantas pizzas de calabresa deseja?"
                   "\n>");
            scanf("%i",&pzc);
            pzc=pzc*somat;
            break;
        case 2:
            pzfc=0;
            wprintf(L"\nQuantas pizzas de frango e catupiry deseja?"
                   "\n>");
            scanf("%i",&pzfc);
            pzfc=pzfc*somat;
            break;
        case 3:
            pzqq=0;
            wprintf(L"\nQuantas pizzas de Quatro queijos deseja?"
                   "\n>");
            scanf("%i",&pzqq);
            pzqq=pzqq*somat;
            break;
        case 4:
            pzb=0;
            wprintf(L"\nQuantas pizzas de Barbecue deseja?"
                   "\n>");
            scanf("%i",&pzb);
            pzb=pzb*somat;
            break;
        case 5:
            pzan=0;
            wprintf(L"\nQuantas pizzas de Ananás deseja?"
                  "\n>");
            scanf("%i",&pzan);
            pzan=pzan*somat;
            break;
        case 6:
            bebsi=0;
            wprintf(L"\nQuantas bebsis precisa?"
                   "\n>");
            scanf("%i",&bebsi);
            bebsi=bebsi*somat;
            break;

        default:
            wprintf(L"saindo do programa...");
            break;
        }

        wprintf(L"\nÉ tudo o que precisa?"
               L"\nSe deseja adicionar mais coisas aperte 1"
               L"\nPara sair aperte 7"
               "\n>");
        scanf("%i",&ch);
    }
    while(opt!=7);
}


void sign()
{

    FILE*aq;

        printf("\nNome:");
        scanf("%s",&login.nome);

        printf("\nSenha:");
        scanf("%s",&login.senha);


        strcat(login.nome,login.senha);
        aq=fopen(login.nome,"w");
        if(aq){
                printf("cadastro feito");
        }

}


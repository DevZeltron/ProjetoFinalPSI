#include <stdio.h>
#include <stdlib.h>
#include <conio.c>
#include <windows.h>
#include <locale.h>
#include <string.h>

struct pop
{
    char nome[50], nomearq[50];
    char senha[50], senhaarq[50];
} login;

struct rock
{
    char name[50], namef[50];
    char passw[50], passwf[50];
} cadastro;

int main()
{
    setlocale(LC_ALL,"Portuguese");
    int opcao;
    int found;
    int ValidLogin=0;


    printf(R"EOF(________       ______             ______       _____________                         _____
__  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
_____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
/____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
       /_/                                                                                               )EOF");



    printf("\nBem-vindo a Splash Pizzaria, a melhor pizza do bairro!!");
    printf("\nAntes de come�ar, ja possui conta na nossa plataforma?"
           "\n\n1 - Sim"
           "\n2 - N�o"
           "\n\n>");
    scanf("%i",&opcao);


        FILE*loggon = fopen("carla.txt","r");

        if (loggon == NULL)
        {
            printf("\nErro ao abrir o arquivo!");
            return 1;
        }


        if(fscanf(loggon, "nome : %s\nsenha: %s",login.nomearq,login.senhaarq) !=2)
        {
            printf("\nError ao ler os dados");
            return 1;
        }

        printf("\nNome:");
        scanf("%s",&login.nome);

        printf("\nSenha:");
        scanf("%s",&login.senha);

        if(strcmp(login.nome,login.nomearq) == 0  && strcmp(login.senha,login.senhaarq) == 0)
        {
            printf("\nLogin feito com successo!\n");
            printf("\nCarregando, estamos a lhe direcionar para o site!\n");

            for(int s=0; s<3; s++)
            {

                printf(".");
                sleep(1);
            }
            printf("\n\nERROR: 404 Bad Gateway!\n"
                   "\nBrincadeira o site ja est� carregando :)\n");
            for(int s=0; s<3; s++)
            {

                printf(".");
                sleep(2);
            }

            system("cls");
            produtos();

        }
        else
        {

            printf("\nUh oh!"
                   "\nParece que o login foi mal-sucedido :(\n");
            printf("\n\nERROR: 404 Bad Gateway!\n"
                   "\nVolte a tentar novamente mais tarde ok? :)\n");
        }


        fclose(loggon);

        if(opcao==1)
    {
        FILE*cadtro = fopen("cadastro.txt","r");

        if (cadtro == NULL)
        {
            printf("\nErro ao abrir o arquivo!");
            return 1;
        }


        if(fscanf(cadtro,"\nnome: %s\npassw: %s",cadastro.namef,cadastro.passwf) !=2)
        {
            printf("\nError ao ler os dados");
            return 1;
        }
        printf("\nNome:");
        scanf("%s",&cadastro.name);

        printf("\nSenha:");
        scanf("%s",&cadastro.passw);


        if(strcmp(cadastro.name,cadastro.namef) == 0  && strcmp(cadastro.passw,cadastro.passwf) == 0)
        {
            printf("\nLogin feito com successo!\n");
            printf("\nCarregando, estamos a lhe direcionar para o site!\n");

            for(int s=0; s<3; s++)
            {

                printf(".");
                sleep(1);
            }
            printf("\n\nERROR: 404 Bad Gateway!\n"
                   "\nBrincadeira o site ja est� carregando :)\n");
            for(int s=0; s<3; s++)
            {

                printf(".");
                sleep(2);
            }

            system("cls");

produtos();
        }
        else
        {

            printf("\nUh oh!"
                   "\nParece que o login foi mal-sucedido :(\n");
            printf("\n\nERROR: 404 Bad Gateway!\n"
                   "\nVolte a tentar novamente mais tarde ok? :)\n");
        }

fclose(cadtro);

    }

    else
    {

        sign();
    }

    return 0;
}


void produtos()
{
    int opt, pzc=0, pzfc=0, pzqq=0, pzb=0, pzan=0, bebsi=0, somat, ch;

    do
    {

        printf("\n---BEM-VINDA NOVAMENTE Carla :)---");
        //printf("\n\n");
        printf(R"EOF(
        _....._
    _.:`.--|--.`:._
  .: .'\o  | o /'. '.
 // '.  \ o|  /  o '.\
//'._o'. \ |o/ o_.-'o\\
|| o '-.'.\|/.-' o   ||
||--o--o-->|             )EOF");

        printf("\n\n");
        printf("\nSelecione qual pizza deseja saborear hoje:"
               "\n(1) -> Pizza de Calabresa"
               "\n(2) -> Pizza de Frango e Catupiry"
               "\n(3) -> Pizza Quatro Queijos"
               "\n(4) -> Pizza de Barbecue"
               "\n(5) -> Pizza Anan�s"
               "\n(6) -> Pepsi Max Zero"
               "\n(7) -> para sair do programa"
               "\n>");
        scanf("%i",&opt);

        switch(opt)
        {
        case 1:
            pzc=0;
            printf("\nQuantas pizzas de calabresa deseja?"
                   "\n>");
            scanf("%i",&pzc);
            pzc=pzc*somat;
            break;
        case 2:
            pzfc=0;
            printf("\nQuantas pizzas de frango e catupiry deseja?"
                   "\n>");
            scanf("%i",&pzfc);
            pzfc=pzfc*somat;
            break;
        case 3:
            pzqq=0;
            printf("\nQuantas pizzas de Quatro queijos deseja?"
                   "\n>");
            scanf("%i",&pzqq);
            pzqq=pzqq*somat;
            break;
        case 4:
            pzb=0;
            printf("\nQuantas pizzas de Barbecue deseja?"
                   "\n>");
            scanf("%i",&pzb);
            pzb=pzb*somat;
            break;
        case 5:
            pzan=0;
            printf("\nQuantas pizzas de Anan�s deseja?"
                   "\n>");
            scanf("%i",&pzan);
            pzan=pzan*somat;
            break;
        case 6:
            bebsi=0;
            printf("\nQuantas bebsis precisa?"
                   "\n>");
            scanf("%i",&bebsi);
            bebsi=bebsi*somat;
            break;

        default:
            printf("saindo do programa...");
            break;
        }

        printf("\n� tudo o que precisa?"
               "\nSe deseja adicionar mais coisas aperte 1"
               "\nPara sair aperte 7"
               "\n>");
        scanf("%i",&ch);
    }
    while(opt!=7);
}


void sign()
{
    FILE*cadtro;
    cadtro=fopen("cadastro.txt","a");

    printf("\nDigite seu nome e crie uma senha"
           "\n>");

    scanf("%s %s",&cadastro.name,&cadastro.passw);

    fprintf(cadtro,"\nnome: %s\npassw: %s",cadastro.name,cadastro.passw);

    fclose(cadtro);

}


#include <stdio.h>
#include <stdlib.h>
#include <windows.h>
#include <locale.h>
#include <string.h>
#include <conio.h>
#include <conio.c>


struct pop
{
    char nome[50];
    char senha[50];
    char file[100];
} login;  //declarao struct com nome pop e é usada para a parte do login

struct rock
{
    char name[50];
    char passw[50];
} cadastro;  //declarao struct com nome rock e é usada para a parte do cadastro

struct rap
{
    int cd, sc[4];
} pag;

int main()
{
    setlocale(LC_ALL,"Portuguese");
    start:;
    system("cls");
    int opcao;
    int found;

textcolor(YELLOW);
    printf(R"EOF(
________       ______             ______       _____________                         _____
__  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
_____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
/____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
       /_/                                                                                               )EOF");


    printf("\nBem-vindo a Splash Pizzaria, a melhor pizza do bairro!!");
    wprintf(L"\nAntes de começar, ja possui conta na nossa plataforma?"
            "\n\n1 - Sim"
            "\n2 - Não"
            "\n\n>");
    scanf("%i",&opcao);

    if(opcao==1)
    {

textcolor(LIGHTBLUE);
        printf("\nNome:");
        scanf("%s",&login.nome);

        printf("\nSenha:");
        scanf("%s",&login.senha);

     strcpy(login.file,login.nome);
     strcat(login.file,login.senha);

      FILE*aq=fopen(login.file,"r");

        if (aq != NULL){
        textcolor(GREEN);
        printf("\nLogin feito com sucesso!\n");
        printf("\nCarregando, estamos a lhe direcionar para o site!\n");

        for(int s=0; s<3; s++)
        {

            printf(".");
            sleep(1);
        }
        textcolor(RED);
        wprintf("\n\nERROR: 404 Bad Gateway!\n");
        textcolor(GREEN);
        wprintf(L"\nBrincadeira o site ja está carregando :)\n");
        for(int s=0; s<3; s++)
        {

            printf(".");
            sleep(2);
        }

        system("cls");
        produtos();

    }
    else
    {
        textcolor(RED);
        printf("\nLogin errado, tente novamente!");
        Sleep(1000);
        textcolor(WHITE);
        goto start;
    }

    } //fecha o if(opcao==1)

    else  //parte da criação da conta
    {

        sign();
    }

    return 0;

}



void produtos()
{

    int opt, pzc=0, pzfc=0, pzqq=0, pzb=0, pzan=0, bebsi=0, z, n;
    float sum=0;
    do
    {
        textcolor(LIGHTBLUE);
        printf("\n---BEM-VINDO(A) NOVAMENTE %s :)---",strupr(login.nome));
        //printf("\n\n");
        printf(R"EOF(
        _....._
    _.:`.--|--.`:._
  .: .'\o  | o /'. '.
 // '.  \ o|  /  o '.\
//'._o'. \ |o/ o_.-'o\\
|| o '-.'.\|/.-' o   ||
||--o--o-->|             )EOF");

        printf("\n\n");
        wprintf(L"\nSelecione qual pizza deseja saborear hoje:"
                L"\n(1) -> Pizza de Calabresa -> 15 Euros"
                L"\n(2) -> Pizza de Frango e Catupiry -> 19.50 Euros"
                L"\n(3) -> Pizza Quatro Queijos -> 19.50 Euros"
                L"\n(4) -> Pizza de Barbecue -> 15 Euros"
                L"\n(5) -> Pizza Ananás -> 30 Euros"
                L"\n(6) -> Pepsi Max Zero -> 2 Euros"
                L"\n(7) -> Ir para a Área de pagamento"
                "\n>");
        scanf("%i",&opt);

        switch(opt)
        {
            textcolor(WHITE);
        case 1:
            pzc=15;
            wprintf(L"\nQuantas pizzas de calabresa deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzc=pzc*z;
            break;
        case 2:
            pzfc=19.50;
            wprintf(L"\nQuantas pizzas de frango e catupiry deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzfc=pzfc*z;
            break;
        case 3:
            pzqq=19.50;
            wprintf(L"\nQuantas pizzas de Quatro queijos deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzqq=pzqq*z;
            break;
        case 4:
            pzb=15;
            wprintf(L"\nQuantas pizzas de Barbecue deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzb=pzb*z;
            break;
        case 5:
            pzan=30;
            wprintf(L"\nQuantas pizzas de Ananás deseja?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            pzan=pzan*z;
            break;
        case 6:
            bebsi=2;
            wprintf(L"\nQuantas bebsis precisa?"
                    "\n>");
            scanf("%i",&z);
            system("cls");
            bebsi=bebsi*z;
            break;

        default: printf("\n");
            break;
        }
textcolor(LIGHTMAGENTA);
        wprintf(L"\nÉ tudo o que precisa?"
                L"\nSe deseja adicionar mais coisas, aperte 1"
                "\nPara ir até a Área de Pagamento, aperte 7"
                "\n>");
        scanf("%i",&n);
        system("cls");

    }while(n!=7);

    sum=pzc+pzfc+pzqq+pzb+pzan+bebsi;

    textcolor(RED);
    wprintf(L"\nValor total a pagar é de: %0.2f\n",sum);
    textcolor(GREEN);
    wprintf("\nComo deseja pagar?"
           L"\n(1) -> Com Cartão de Crédtio"
           "\n(2) -> Dinheiro"
           "\n>");
           scanf("%i",&pag.cd);

textcolor(WHITE);
           if(pag.cd==1)
            {
            wprintf(L"\nDigite a senha do seu cartão"
                   "\n>");
            scanf("%i",&pag.sc);
            textcolor(WHITE);
            printf("\nRealizando a compra");
            for(int x=0;x<3;x++){
                printf(".");
                sleep(1);
              }
textcolor(WHITE);
              printf("\nAguarde um momento por favor!");
              for(int y=0;y<3;y++){
                printf(".");
                sleep(2);
                }
                textcolor(GREEN);
              printf("\n\nCompra realizada com sucesso!");
              textcolor(GREEN);
              printf("\n\nPor favor, aguarde o Delivery de 10 segundos!");
                     sleep(10);
                     textcolor(GREEN);
                     system("cls");

                     printf(R"EOF(

            ________       ______             ______       _____________                         _____
            __  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
            _____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
            ____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
            /____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
                    /_/                                                                                               )EOF");



       printf("\n\n\t\t\tA sua pizza chegou!"
              "\n\t\t\tEspero que goste da nossa pizza, %s! :)\n"
              "\n\t\t\tPor favor, verifique o seu talão",strlwr(login.nome));
              textcolor(WHITE);

              FILE*Talao;

              Talao=fopen("talao.txt","a");

              fprintf(Talao,R"EOF(

            ________       ______             ______       _____________                         _____
            __  ___/__________  /_____ __________  /_      ___  __ \__(_)________________ __________(_)_____ _
            _____ \___  __ \_  /_  __ `/_  ___/_  __ \     __  /_/ /_  /___  /__  /_  __ `/_  ___/_  /_  __ `/
            ____/ /__  /_/ /  / / /_/ /_(__  )_  / / /     _  ____/_  / __  /__  /_/ /_/ /_  /   _  / / /_/ /
            /____/ _  .___//_/  \__,_/ /____/ /_/ /_/      /_/     /_/  _____/____/\__,_/ /_/    /_/  \__,_/
                    /_/                                                                                               )EOF"

                      "\n\nMorada: 1000 Av. Pedro Teixeira, Lisboa, Portugal"
                      "\nNIF: 295230014"
                      "\nProdutos:");

                      fclose(Talao);
           }

}


void sign()
{

    FILE*aq;
    textcolor(LIGHTMAGENTA);

    printf("\nNome:");
    scanf("%s",&login.nome);

    printf("\nSenha:");
    scanf("%s",&login.senha);


    strcat(login.nome,login.senha);

    aq=fopen(login.nome,"w");
    if(aq)
    {
        textcolor(WHITE);
        printf("\nCadastro feito com sucesso!\n");
    }

}

